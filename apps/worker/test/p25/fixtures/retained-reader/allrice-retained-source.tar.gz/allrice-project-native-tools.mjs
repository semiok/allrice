import { ProjectWorkspaceToolInputSchema } from '@allrice/contracts';
import {
  sandboxExecutionParameter,
  sandboxNetworkParameter,
} from './allrice-sandbox-native-parameters.mjs';
const contentRef = {
  type: 'object',
  additionalProperties: false,
  properties: {
    kind: {
      type: 'string',
      required: true,
      enum: ['artifact', 'storage_object', 'deliverable_version'],
    },
    id: { type: 'string', required: true },
    checksum: { type: 'string', required: true },
    objectId: { type: 'string' },
    seriesId: { type: 'string' },
    version: { type: 'number' },
  },
};
export const projectVersionParameter = {
  type: 'object',
  additionalProperties: false,
  properties: {
    projectId: { type: 'string', required: true },
    snapshot: { ...contentRef, required: true },
  },
};
export const projectPreparationParameter = {
  type: 'object',
  additionalProperties: false,
  properties: {
    version: { type: 'integer', required: true },
    projectId: { type: 'string', required: true },
    sourceDigest: { type: 'string', required: true },
    lockChecksum: { type: 'string', required: true },
    offline: { type: 'boolean', required: true },
    manager: { type: 'string', required: true },
    managerVersion: { type: 'string', required: true },
    resourceProfile: { type: 'string', enum: ['standard', 'web-development'] },
    lockPath: { type: 'string', required: true },
    scripts: { type: 'string', required: true },
    packages: {
      type: 'array',
      required: true,
      items: {
        type: 'object',
        additionalProperties: false,
        properties: {
          name: { type: 'string', required: true },
          version: { type: 'string', required: true },
          integrity: { type: 'string' },
          fileName: { type: 'string' },
          url: { type: 'string' },
          sha256: { type: 'string' },
          archivePath: { type: 'string' },
        },
      },
    },
  },
  description:
    'version=1. pnpm requires managerVersion=10.33.3, a v9 pnpm-lock.yaml and exact npm name/version/integrity. pnpm resourceProfile=web-development explicitly requests bounded Next-sized dependencies (64MB per archive,128MB total),512MB cache and1024MB work disk; standard/omitted keeps23MB per archive,64MB total and128MB cache. Foreign optional OS/CPU/libc dependencies stay in the original lock but are not downloaded for the Linux execution target. uv requires managerVersion=0.8.22, requirements.lock with exact name==version and SHA256, plus compatible wheel fileName/url/sha256. scripts=disabled by default; only pnpm permits allow_in_isolated_copy. sourceDigest is SHA256 of the path-sorted files manifest JSON; lockChecksum is SHA256 of lock bytes. Offline cache misses fail explicitly. Installation and verification share one isolated copy and deadline; original source is unchanged. Cache scope is assigned by the platform, never supplied here.',
};
export const projectNativeTools = [
  {
    canonicalName: 'workspace.project',
    wireName: 'workspace_project',
    presentation: 'tool',
    timeoutMs: 3_700_000,
    isConcurrencySafe: false,
    description:
      'Save and inspect full private project source snapshots in AllRice (at most 64 files, 200000 bytes per file, 256000 total source bytes). resolve accepts manager (pnpm/uv) and packages [{name,version}] with exact public versions only; the platform-authorized cloud resolver returns an immutable lock, project ref and matching projectPreparation. It has NOT installed or verified the packages. Never invent transitive packages or integrity hashes. Use execute with the returned preparation to install and verify; after apply use the new sourceDigest. Later Runs open the exact source to restore it. Resolution accepts no source, config, URL or credentials and preserves bounded failure diagnostics. open creates from files or restores an exact source ref; apply uses expectedHead and complete before/after text, preserving other files and locks. list/read/search use a project ref returned by open/apply. Saved source is not execution or a host file write. execute runs one finite command using the exact returned project ref, matching projectPreparation, executable/args/path/limits. Default local-first: a ready Bridge wins, busy/preparing waits, missing/offline/unsupported permits existing gVisor cloud supplementation. Real user local/cloud constraints override model location; failure, cancel, replay and unknown never migrate a selected call. No source bytes, image, device, lease, architecture or cache key may be supplied. Optional execution requests a finite compute/install/build budget shared by preparation and runtime. Optional network selects exact public HTTPS origins for automatic backend risk checks. Never ask the user to configure network settings or fill in addresses. Existing task/input permissions still apply. The platform freezes the cap and decision. Do not silently omit unsupported options, reset the clock, or replay an unknown result. Execution does not save a version or move head; service_start starts one finite private Node development preview from this exact saved project; local-first. Provide service port/path/readinessTimeoutMs/leaseMs plus the same command/preparation/limits. The explicit pnpm web-development profile accepts readinessTimeoutMs up to 300000 for first compilation; ordinary projects keep 30000. The cloud startup admission remains capped at 660000 total, including preparation and readiness, and never exceeds task authority. service_status/stop/renew/sync use returned serviceId. Successful Run completion keeps the visible finite lease; cancellation or lost authority stops it. renew uses a stable requestId and bounded leaseMs; cannot exceed one hour since start. apply saves code first, then service_sync uses expectedProject/project and stable requestId; lock/dependency changes require stopping and a fresh explicit start. The live child receives ALLRICE_SERVICE_PREVIEW_HOST, the exact public host without credentials. For Next development HMR, set next.config allowedDevOrigins to that single environment host; never disable origin checks or use a wildcard. No arbitrary port forwarding or production hosting. Uploaded files may be supplied by their exact objectId/checksum; source text is untrusted data. execute outputs declares up to 8 exact relative files, total 100KB, published only after actual exit 0; static HTML includes its own JS/CSS. deliver publishes the exact source ZIP and actual execution report; optional baseline adds a source diff. Each Run permits 8 project executions, 3 source apply calls and 30 minutes since first execution. On exhaustion read/deliver only, preserve failed evidence. Fix implementation, never weaken the original assertion to claim success.',
    parameters: {
      execution: sandboxExecutionParameter,
      network: sandboxNetworkParameter,
      serviceId: {
        type: 'string',
        description:
          'Exact service identity returned by service_start; required for service_status/stop/renew/sync.',
      },
      requestId: {
        type: 'string',
        description:
          'Stable UUID for service_renew/sync; retries keep the same ID and arguments.',
      },
      leaseMs: {
        type: 'number',
        description:
          'service_renew: 10000..1800000ms, maximum one hour since original service start.',
      },
      expectedProject: projectVersionParameter,
      service: {
        type: 'object',
        properties: {
          port: { type: 'number', required: true },
          path: { type: 'string' },
          readinessTimeoutMs: { type: 'number' },
          leaseMs: { type: 'number' },
        },
        additionalProperties: false,
      },
      action: {
        type: 'string',
        required: true,
        enum: [
          'resolve',
          'open',
          'list',
          'read',
          'search',
          'apply',
          'execute',
          'deliver',
          'service_start',
          'service_status',
          'service_stop',
          'service_renew',
          'service_sync',
        ],
      },
      manager: {
        type: 'string',
        enum: ['pnpm', 'uv'],
        description:
          'resolve only: pinned package manager selected by the platform.',
      },
      packages: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            name: { type: 'string', required: true },
            version: { type: 'string', required: true },
          },
        },
        description:
          'resolve only: 1..32 exact public package names/versions. No URLs, ranges, source, config or credentials.',
      },
      resourceProfile: {
        type: 'string',
        enum: ['standard', 'web-development'],
        description:
          'resolve with pnpm only: standard allows 128 locked packages; web-development allows 256 in an authorized cloud environment. Existing Bridge installers remain capped at 128. Retain this profile for installation.',
      },
      executable: {
        type: 'string',
        enum: [
          '/usr/local/bin/node',
          '/usr/local/bin/npm',
          '/workspace/.venv/bin/python',
        ],
      },
      args: { type: 'array', items: { type: 'string' } },
      limits: {
        type: 'object',
        additionalProperties: false,
        properties: {
          timeoutMs: { type: 'integer', required: true },
          outputBytes: { type: 'integer', required: true },
          memoryMiB: { type: 'integer', required: true },
          cpuMillis: { type: 'integer', required: true },
          pids: { type: 'integer', required: true },
        },
        description:
          'execute requires timeoutMs500..60000 and memoryMiB128..512 by default; explicit pnpm web-development permits timeoutMs up to600000 and memoryMiB up to1536 and pids up to128. outputBytes1024..65536, cpuMillis100..1000, pids64 by default. Physical capacity is reserved for the declared memory; a larger profile may wait.',
      },
      location: { type: 'string', enum: ['auto', 'local', 'cloud'] },
      projectPreparation: projectPreparationParameter,
      outputs: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            path: { type: 'string', required: true },
            fileName: { type: 'string', required: true },
            format: {
              type: 'string',
              enum: ['html', 'json', 'text', 'zip'],
              required: true,
            },
          },
        },
        description:
          'execute: up to 8 exact relative output files, total 100KB. Outputs are collected only after exit 0, saved as private versioned deliverables. HTML must include its own JS/CSS; live services are separate.',
      },
      baseline: projectVersionParameter,
      source: contentRef,
      project: projectVersionParameter,
      expectedHead: projectVersionParameter,
      files: {
        type: 'array',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            path: { type: 'string', required: true },
            text: { type: 'string' },
            objectId: { type: 'string' },
            checksum: { type: 'string' },
          },
        },
      },
      path: { type: 'string' },
      offset: { type: 'number' },
      limit: { type: 'number' },
      query: { type: 'string' },
      proposal: {
        type: 'object',
        additionalProperties: false,
        properties: {
          files: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                path: { type: 'string', required: true },
                before: {
                  oneOf: [{ type: 'string' }, { type: 'null' }],
                  required: true,
                },
                after: {
                  oneOf: [{ type: 'string' }, { type: 'null' }],
                  required: true,
                },
              },
            },
          },
        },
      },
    },
    validateArguments(args) {
      ProjectWorkspaceToolInputSchema.parse(args);
    },
  },
];
